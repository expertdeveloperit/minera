import { Component, OnInit } from '@angular/core';
import {Http} from "@angular/http";
import {ActivatedRoute,Router} from '@angular/router';
import { UrlConfig } from '../../../services/urlProviders';
import {CommonService} from '../../../services/common.service';
declare var $: any; 

@Component({
  selector: 'app-rewards',
  templateUrl: './rewards.component.html',
  styleUrls: ['./rewards.component.css']
})
export class RewardsComponent implements OnInit {


  public data;
  public datasec;
  public loading = false;//loader
  rewardsInfo=[];
  rewardsPrice;
  totalRewards=0;
  constructor(private http: Http,private route:Router,private service:CommonService) { }
  ngOnInit(): void {
    this.loading = true;
     let URL="";
     let PriceUrl = "";
     URL =  UrlConfig.admin.getRewards;
     PriceUrl = UrlConfig.admin.getbtcprice;
     
      this.service.getExternalData(PriceUrl).subscribe((data)=> {
       this.rewardsPrice = parseFloat(data.data.rates['USD']);
       console.log(this.rewardsPrice);
       this.loading = false; 
      
    });

     this.service.get(URL).subscribe((data)=> {
       this.rewardsInfo = data;
       var sum=0;
       for(let i=0;i<this.rewardsInfo.length;i++){
         sum = sum + parseInt(this.rewardsInfo[i].reward);
       }
       this.totalRewards=sum;
       this.loading = false; 
    });
    }
    refreshDatatable(){
      if(!$( "#orderTable" ).hasClass("init")){
        $('#orderTable').DataTable();
        $( "#orderTable" ).addClass("init");
      }
    }
}


